class Book {
    private final int id;
    private final String title;
    private final String author;
    private boolean available;

    public Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.available = true;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public boolean isAvailable() {
        return available;
    }

    public void borrowBook() {
        available = false;
    }

    public void returnBook() {
        available = true;
    }

    public void displayBook() {
        System.out.println(id + " | " + title + " | " + author +
                " | " + (available ? "Available" : "Borrowed"));
    }
}