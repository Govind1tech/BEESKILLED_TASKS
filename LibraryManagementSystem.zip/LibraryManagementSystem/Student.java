class Student extends User {

    public Student(String name) {
        super(name);
    }

    @Override
    public void displayUser() {
        System.out.println("Student Name: " + name);
    }
}