import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Library library = new Library();
        Student student = new Student("Govind");

        try (Scanner sc = new Scanner(System.in)) {
            library.addBook(new Book(1, "Java Programming", "James Gosling"));
            library.addBook(new Book(2, "Python Basics", "Guido van Rossum"));
            library.addBook(new Book(3, "Data Structures", "Mark Allen"));
            
            student.displayUser();
            
            int choice;
            
            do {
                System.out.println("\n===== Library Management System =====");
                System.out.println("1. Display Books");
                System.out.println("2. Add Book");
                System.out.println("3. Borrow Book");
                System.out.println("4. Return Book");
                System.out.println("5. Exit");
                System.out.print("Enter choice: ");
                choice = sc.nextInt();
                
                switch (choice) {
                    case 1 -> library.displayBooks();
                    case 2 -> {
                        System.out.print("Enter Book ID: ");
                        int id = sc.nextInt();
                        sc.nextLine();

                        System.out.print("Enter Book Title: ");
                        String title = sc.nextLine();

                        System.out.print("Enter Author Name: ");
                        String author = sc.nextLine();

                        library.addBook(new Book(id, title, author));
                    }
                    case 3 -> {
                        System.out.print("Enter Book ID to Borrow: ");
                        int id = sc.nextInt();
                        library.borrowBook(id);
                    }
                    case 4 -> {
                        System.out.print("Enter Book ID to Return: ");
                        int id = sc.nextInt();
                        library.returnBook(id);
                    }
                    case 5 -> System.out.println("Thank You!");
                    default -> System.out.println("Invalid Choice.");
                }
                
            } while (choice != 5);
        }
    }
}