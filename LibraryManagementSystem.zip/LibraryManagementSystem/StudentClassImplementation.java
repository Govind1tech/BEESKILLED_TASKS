
class Student {
    // Attributes (Fields)
    private String name;
    private String studentId;
    private String major;
    private double gpa;

    // Constructor to initialize the attributes
    public Student(String name, String studentId, String major, double gpa) {
        this.name = name;
        this.studentId = studentId;
        this.major = major;
        this.gpa = gpa;
    }

    // Method to display student info
    public void displayInfo() {
        System.out.println("--- Student Information ---");
        System.out.println("Name:       " + this.name);
        System.out.println("ID:         " + this.studentId);
        System.out.println("Major:      " + this.major);
        System.out.println("GPA:        " + this.gpa);
        System.out.println("---------------------------");
    }

    // --- Example Usage ---
    public static void main(String[] args) {
        // Creating a student object
        Student student1 = new Student("Alex Rivera", "STU9876", "Computer Science", 3.85);

        // Displaying the student's info
        student1.displayInfo();
    }
}
