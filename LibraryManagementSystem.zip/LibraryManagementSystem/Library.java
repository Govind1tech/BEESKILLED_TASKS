import java.util.ArrayList;

class Library {
    private final ArrayList<Book> books = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
        System.out.println(book.getTitle() + " added successfully.");
    }

    public void displayBooks() {
        System.out.println("\nLibrary Books:");
        for (Book b : books) {
            b.displayBook();
        }
    }

    public void borrowBook(int id) {
        for (Book b : books) {
            if (b.getId() == id) {
                if (b.isAvailable()) {
                    b.borrowBook();
                    System.out.println("Book borrowed successfully.");
                } else {
                    System.out.println("Book is already borrowed.");
                }
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void returnBook(int id) {
        for (Book b : books) {
            if (b.getId() == id) {
                b.returnBook();
                System.out.println("Book returned successfully.");
                return;
            }
        }
        System.out.println("Book not found.");
    }
}